#!/bin/sh
fn=""
PaPWD="$PWD"
stdcdr="stdcdr"
stdcdrd=""
while [ ! -f "$stdcdrd$stdcdr" ];do
    stdcdrd=$(echo "../$stdcdrd")
done
PrPWD=$stdcdrd
pasa=0
nomprograma=$0
slash=$(echo "$nomprograma"| $PrPWD/stdbuscaarg_donde_hasta "/" )
while [ -n "$slash" ];do
    nomprograma=$(echo "$nomprograma"| $PrPWD/stdcdr "/" )
    slash=$(echo "$nomprograma" | $PrPWD/stdbuscaarg_donde_hasta "/" )
done
cd $PrPWD
PrPWD2=$PWD
PrPWD=$PrPWD2
cd $PaPWD
#echo "$nomprograma.."
sleep 0.1
listados="";
listado="";
if [ -d "$PrPWD/users/input" ];then
    listados=$(echo $PrPWD/users/input|$PrPWD/listadodirectorio_dirs_from_std|$PrPWD/stdbuscaarg_donde '
')
    listado=$(echo $PrPWD/users/input|$PrPWD/listadodirectorio_dirs_from_std)
    salta=0;
    while [ -n "$listados" ];do
	presalta=$(echo -n "$listados" | $PrPWD/stdcar " ")
	dirn=$(echo -n "$listado"|$PrPWD/stdcdrn 0$salta | $PrPWD/stdcarn $presalta)
	lista1=$(echo "$dirn" | $PrPWD/listadodirectorio_files_from_std_extension_c )
	lista2=$(echo -n "$lista1
$lista0" )
	lista0=$lista2
	salta=$(expr "$presalta + 1")
	listados=$(echo -n "$listados" | $PrPWD/stdcdr " ")
    done
fi
echo "<<< $lista0 >>>"
busca=".."
posicion=0;
dondes=$( echo "$lista0" |$PrPWD/stdbuscaarg_donde "
")
encuentra="ALGO"
while [ -n "$dondes" -a -n "$encuentra" ];do
    listf=$(echo "$lista0" | $PrPWD/stdcdrn "0$posicion"|$PrPWD/stdcarsin '
')
    posicion=$(echo "$dondes" |$PrPWD/stdcarsin " ")
    posicion=$(expr 0$posicion + 1)
    dondes=$(echo "$dondes" |$PrPWD/stdcdr " ")
    chacha=$(echo "$listf"|$PrPWD/chacha20)
    encuentra=$(cat $nomprograma.memoria | $PrPWD/stdbuscaarg ";$listf;$chacha;")
done
if [ -z "$encuentra" ];then
    echo ";$listf;$chacha;" >> $nomprograma.memoria
fi
if [ -n "$dondes" ];then
    $0 &
else
    ps1=3
    while [ 0$ps1 -gt 2 ];do
    	ps1=$(ps -Am -o ";%c:" |  $PrPWD/stddelcar " " | $PrPWD/stdbuscaarg_count ";$nomprograma:" )
    	sleep 2
    done
    $0 &
fi
if [ -z "$encuentra" ];then
    fn=$listf
    echo "<< fn $fn >>"
    ttest=$(echo -n "$fn" |$PrPWD/stddelcar " ")
    if [ -n "$ttest" ];then
	slash=$(echo "$fn" | $PrPWD/stdbuscaarg_donde_hasta "/" )
	fn2="$fn"
	while [ -n "$slash" ];do
	    fn2=$(echo -n "$fn2" | $PrPWD/stdcdr "/" )
	    slash=$(echo -n "$fn2" | $PrPWD/stdbuscaarg_donde_hasta "/" )
	done
	dirfn=$(echo -n "$fn"|$PrPWD/stdcarsin "/$fn2")
	mkdir "$dirfn/data"
	dirfn=$(echo -n "$dirfn/data" )
    	echo "0 $busca ($fn2) $dirfn"
	len=$(cat "$fn"|wc -c)
	if [ 0$len -gt 0 ];then
	    mains=$(cat "$fn"|$PrPWD/stdbuscaarg " main")
	    opens=$(cat "$fn"|$PrPWD/stdcdr " main"|$PrPWD/stdbuscaarg_count "{")
	    closs=$(cat "$fn"|$PrPWD/stdcdr " main"|$PrPWD/stdbuscaarg_count "}")
	    balan=$(echo "$opens-$closs"|bc)
	    echo "$len $opens-$closs"
	    if [ 0$opens -gt 0 -a "$balan" = "0" -a -n "$mains" ];then
    		ejec="$fn.$nomprograma.bin"
		echo "E: $ejec"
		errores=$(gcc -o "$ejec" "$fn" 2>&1 )
		if [ -z "$errores" ];then
		    variables=$(cat $fn |$PrPWD/stddeclaracionesdevariable|tr '
' ';')
		    fechan=$(echo -n ";$variables" |$PrPWD/stdcdr ";time_t "|$PrPWD/stdcarsin ";"|$PrPWD/stdcarsin "=")
		    fecha=$(echo -n ";$variables" |$PrPWD/stddelcar " "|$PrPWD/stdcdr "$fechan="|$PrPWD/stdcarsin ";")
		    latitud=$(echo -n ";$variables"|$PrPWD/stddelcar ' '|$PrPWD/stdcdr ";doublelatitud="|$PrPWD/stdcarsin ";")
		    longitud=$(echo -n ";$variables"|$PrPWD/stddelcar ' '|$PrPWD/stdcdr ";doublelongitud="|$PrPWD/stdcarsin ";")
		    timezone=$(echo -n ";$variables"|$PrPWD/stddelcar ' '|$PrPWD/stdcdr ";floattimezone="|$PrPWD/stdcarsin ";")
		    echo "fechanon: $fechan fechav: $fecha $latitud $longitud .............."

		    utcc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$utcc.c" ];do
			utcc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done

		    cat $PrPWD/tmtoutcdate.c | $PrPWD/stdcar "time_t t=" > "$dirfn/$utcc.c"
		    echo -n "$fecha;" >> "$dirfn/$utcc.c"
		    cat $PrPWD/tmtoutcdate.c |  $PrPWD/stdcdr "time_t t=" | $PrPWD/stdcdr ";" >> "$dirfn/$utcc.c"
		    timeerrores=$(gcc -o "$dirfn/$utcc" "$dirfn/$utcc.c" -lm 2>&1 )
		    if [ -z "$timeerrores" ];then
			timed=$("$dirfn/$utcc")
			yeard=$(echo "$timed"|$PrPWD/stdcarsin "/"|$PrPWD/stddelcar " ")
			mond=$(echo "$timed"|$PrPWD/stdcdr "/"|$PrPWD/stdcarsin "/"|$PrPWD/stddelcar " ")
			dayd=$(echo "$timed"|$PrPWD/stdcdr "/"|$PrPWD/stdcdr "/"|$PrPWD/stdcarsin " "|$PrPWD/stddelcar " ")
			horad=$(echo "$timed"|$PrPWD/stdcdr "/"|$PrPWD/stdcdr " "|$PrPWD/stdcarsin ":"|$PrPWD/stddelcar " ")
			mind=$(echo "$timed"|$PrPWD/stdcdr "/"|$PrPWD/stdcdr ":"|$PrPWD/stdcarsin " "|$PrPWD/stddelcar " ")

			echo "..:: $timed ::.."
			cad=$(echo "$timed" | /media/A/nube/comp/cspice/planetas_std|$PrPWD/stddeclaracionesdevariable|tr '
' ';')
			echo "$timed" | /media/A/nube/comp/cspice/planetas_std
			et=$(echo ";$cad" |  $PrPWD/stdcdr ";double et=" | $PrPWD/stdcarsin ";")
			planetas_array=$(echo ";$cad"|$PrPWD/stdcdr ";char planet_names"|$PrPWD/stdcarsin ";")
			positions_array=$(echo ";$cad"|$PrPWD/stdcdr ";double RA"|$PrPWD/stdcarsin ";")
		        declinations_array=$(echo ";$cad"|$PrPWD/stdcdr ";double DEC"|$PrPWD/stdcarsin ";")
			echo "$cad"
		    fi
		    
		    aspecas=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$aspecas.c" ];do
			aspecas=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done

		    cat $PrPWD/swe/src/swe_ecl_a.c | $PrPWD/stdcar "double positions" > "$dirfn/$aspecas.c"
		    echo "$positions_array;" >> "$dirfn/$aspecas.c"
		    cat $PrPWD/swe/src/swe_ecl_a.c | $PrPWD/stdcdr "double positions" | $PrPWD/stdcdr ";" >> "$dirfn/$aspecas.c"
		    cat "$dirfn/$aspecas.c" | $PrPWD/stdcar "char planets" > "$dirfn/$aspecas-1.c"
		    echo "$planetas_array;" >> "$dirfn/$aspecas-1.c"
		    cat "$dirfn/$aspecas.c" | $PrPWD/stdcdr "char planets" | $PrPWD/stdcdr ";" >> "$dirfn/$aspecas-1.c"
		    cat "$dirfn/$aspecas-1.c" | $PrPWD/stdcar "char aspects" > "$dirfn/$aspecas.c"
		    echo "[5]={0,  60, 90, 120, 180}; " >> "$dirfn/$aspecas.c"
		    cat "$dirfn/$aspecas-1.c" | $PrPWD/stdcdr "char aspects" | $PrPWD/stdcdr ";" >> "$dirfn/$aspecas.c"
		    cat "$dirfn/$aspecas.c" | $PrPWD/stdcar "double toleranc" > "$dirfn/$aspecas-1.c"
		    echo "[5]={4.50, 2, 3, 3, 4};" >> "$dirfn/$aspecas-1.c"
		    cat "$dirfn/$aspecas.c" | $PrPWD/stdcdr "double toleranc" | $PrPWD/stdcdr ";" >> "$dirfn/$aspecas-1.c"
		    mv "$dirfn/$aspecas-1.c" "$dirfn/$aspecas.c"
		    aspectroseclerrores=$(gcc -o "$dirfn/$aspecas" "$dirfn/$aspecas.c" -lm 2>&1 )
		    if [ -z "$aspectroseclerrores" ];then
			cad=$("$dirfn/$aspecas")
			echo "/*/*/*/*/*"
			cat "$dirfn/$aspecas.c"
			echo "$cad"
			echo "*/*/*/*/*/*/"
			variables=$(echo ";$cad"|$PrPWD/stddeclaracionesdevariable|tr '
' ';')
			variables=$(echo ";$variables"|$PrPWD/stddelcar ";static "|$PrPWD/stddelcar ";const ")
			echo "<<(($variables))>>"
			aspectosasc="";
			planet1=$(echo -n ";$variables" |$PrPWD/stdcdr ";char "|$PrPWD/stdcarsin ";")
			aspectosasc="$aspectosasc;char ascencional_$planet1;"
			planet1=$(echo -n ";$variables" |$PrPWD/stddelcar " "|$PrPWD/stddelcar "intmain"|$PrPWD/stdcdr ";int"|$PrPWD/stdcarsin ";")
			aspectosasc="$aspectosasc;int ascencional_$planet1;"
			aspectosnombre=$(echo -n "$planet1"|$PrPWD/stdcarsin "["|$PrPWD/stdcarsin "=")			
			planet1=$(echo -n ";$variables" |$PrPWD/stddelcar " "|$PrPWD/stdcdr ";double"|$PrPWD/stdcarsin ";")
			aspectosasc="$aspectosasc;double ascencional_$planet1;"
			gradosn=$(echo -n "$planet1"|$PrPWD/stdcarsin "["|$PrPWD/stdcarsin "=")
			echo "<. <. < $gradosn|$aspectosnombre > .> .>"|$PrPWD/stddelcar " "
			variables=$(echo "$cad"|tr '
' ';'|$PrPWD/stddelcar " "|$PrPWD/stddelcar "$gradosn"|$PrPWD/stddelcar "$aspectosnombre")
			echo "<. <. < $variables > .> .>"|$PrPWD/stddelcar " "
			aspecto="ALGO"
			while [ -n "$aspecto" -a -n "$aspectosnombre" ];do
			    aspecto=$(echo -n "$variables"|$PrPWD/stdcdrcon ";$aspectosnombre"|$PrPWD/stdcarsin ";")
			    caracter=$(echo -n "$aspecto"|$PrPWD/stdcdr ";$aspectosnombre"|$PrPWD/stdcarn 1)
			    if [ "$caracter" = "[" -o "$caracter" = "=" ];then
				aspectosasc="$aspectosasc;$aspecto;"
			    fi
			    variables=$(echo "$variables"|$PrPWD/stdcdr ";$aspectosnombre")
			done
			variables=$(echo "$cad"|tr '
' ';'|$PrPWD/stddelcar " ")
			aspecto="ALGO"
			while [ -n "$aspecto" -a -n "$gradosn" ];do
			    aspecto=$(echo -n "$variables"|$PrPWD/stdcdrcon ";$gradosn"|$PrPWD/stdcarsin ";")
			    caracter=$(echo -n "$aspecto"|$PrPWD/stdcdr ";$gradosn"|$PrPWD/stdcarn 1)
			    if [ "$caracter" = "[" -o "$caracter" = "=" ];then
				aspectosasc="$aspectosasc;$aspecto;"
			    fi
			    variables=$(echo "$variables"|$PrPWD/stdcdr ";$gradosn")
			done
		    fi

		    echo "________________"
		    
		    ffc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$ffc.c" ];do
			ffc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done

		    cat $PrPWD/ASC.c | $PrPWD/stdcar "double obslon=" > "$dirfn/$ffc.c"
		    echo "$longitud ;" >> "$dirfn/$ffc.c"
		    cat $PrPWD/ASC.c | $PrPWD/stdcdr "double obslon=" | $PrPWD/stdcdr ";" >> "$dirfn/$ffc.c"
		    cat "$dirfn/$ffc.c" | $PrPWD/stdcar "double obslat=" > "$dirfn/$ffc-1.c"
		    echo "$latitud ;" >> "$dirfn/$ffc-1.c"
		    cat "$dirfn/$ffc.c" | $PrPWD/stdcdr "double obslat=" | $PrPWD/stdcdr ";"  >> "$dirfn/$ffc-1.c"
		    cat "$dirfn/$ffc-1.c" | $PrPWD/stdcar "double et=" > "$dirfn/$ffc.c"
		    echo "$et ; // <-- A " >> "$dirfn/$ffc.c"
		    cat "$dirfn/$ffc-1.c" | $PrPWD/stdcdr "double et=" | $PrPWD/stdcdr ";"  >> "$dirfn/$ffc.c"
		    cat "$dirfn/$ffc.c" | $PrPWD/stdcar "double tz=" > "$dirfn/$ffc-1.c"
		    echo "$timezone ;" >> "$dirfn/$ffc-1.c"
		    cat "$dirfn/$ffc.c" | $PrPWD/stdcdr "double tz=" | $PrPWD/stdcdr ";"  >> "$dirfn/$ffc-1.c"
		    mv "$dirfn/$ffc-1.c" "$dirfn/$ffc.c"

		    ascendenteerrores=$(gcc -o "$dirfn/$ffc" "$dirfn/$ffc.c" -lm 2>&1 )
		    if [ -z "$ascendenteerrores" ];then

			tjdf=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
			while [ -f "$dirfn/$tjdf.c" ];do
			    tjdf=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
			done

			cat $PrPWD/utctojd.c | $PrPWD/stdcar "int Y=" > "$dirfn/$tjdf.c"
			echo "$yeard ;" >> "$dirfn/$tjdf.c"
			cat $PrPWD/utctojd.c | $PrPWD/stdcdr "int Y=" | $PrPWD/stdcdr ";" >> "$dirfn/$tjdf.c"
			
			cat "$dirfn/$tjdf.c" | $PrPWD/stdcar "int M=" > "$dirfn/$tjdf-1.c"
			echo "$mond ;" >> "$dirfn/$tjdf-1.c"
			cat "$dirfn/$tjdf.c" | $PrPWD/stdcdr "int M=" | $PrPWD/stdcdr ";"  >> "$dirfn/$tjdf-1.c"
			
			cat "$dirfn/$tjdf-1.c" | $PrPWD/stdcar "int D=" > "$dirfn/$tjdf.c"
			echo "$dayd ; // <-- A " >> "$dirfn/$tjdf.c"
			cat "$dirfn/$tjdf-1.c" | $PrPWD/stdcdr "int D=" | $PrPWD/stdcdr ";"  >> "$dirfn/$tjdf.c"
			
			cat "$dirfn/$tjdf.c" | $PrPWD/stdcar "double H=" > "$dirfn/$tjdf-1.c"
			echo "$horad ;" >> "$dirfn/$tjdf-1.c"
			cat "$dirfn/$tjdf.c" | $PrPWD/stdcdr "double H=" | $PrPWD/stdcdr ";"  >> "$dirfn/$tjdf-1.c"
			
			cat "$dirfn/$tjdf-1.c" | $PrPWD/stdcar "double N=" > "$dirfn/$tjdf.c"
			echo "$mind ; //<-" >> "$dirfn/$tjdf.c"
			cat "$dirfn/$tjdf-1.c" | $PrPWD/stdcdr "double N=" | $PrPWD/stdcdr ";"  >> "$dirfn/$tjdf.c"
			
			utctojulianerror=$(gcc -o "$dirfn/$tjdf" "$dirfn/$tjdf.c" -lm 2>&1 )
			echo "E:< { $utctojulianerror } >"
			tjd=$("$dirfn/$tjdf")
		    fi
		    
		    swecl=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$swecl.c" ];do
			swecl=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done

		    cat $PrPWD/swe/src/swe_ecl.c | $PrPWD/stdcar "double geo_lon=" > "$dirfn/$swecl.c"
		    echo "$longitud ;" >> "$dirfn/$swecl.c"
		    cat $PrPWD/swe/src/swe_ecl.c | $PrPWD/stdcdr "double geo_lon=" | $PrPWD/stdcdr ";" >> "$dirfn/$swecl.c"
		    cat "$dirfn/$swecl.c" | $PrPWD/stdcar "double geo_lat=" > "$dirfn/$swecl-1.c"
		    echo "$latitud ;" >> "$dirfn/$swecl-1.c"
		    cat "$dirfn/$swecl.c" | $PrPWD/stdcdr "double geo_lat=" | $PrPWD/stdcdr ";"  >> "$dirfn/$swecl-1.c"
		    cat "$dirfn/$swecl-1.c" | $PrPWD/stdcar "double tjd=" > "$dirfn/$swecl.c"
		    echo "$tjd ; // <-- A " >> "$dirfn/$swecl.c"
		    cat "$dirfn/$swecl-1.c" | $PrPWD/stdcdr "double tjd=" | $PrPWD/stdcdr ";"  >> "$dirfn/$swecl.c"
		    posicioneclipticoserrores=$(gcc -o $dirfn/$swecl $dirfn/$swecl.c -lm -lswe -L$PrPWD/swe/src -I$PrPWD/swe/src 2>&1 )
		    if [ -z "$posicioneclipticoserrores" ];then
			echo "E:< { $posicioneclipticoserrores } >"

			cad=$("$dirfn/$swecl"|tr '
' ';')
			ecl_planetas_array=$(echo ";$cad"|$PrPWD/stdcdr ";char planets_names"|$PrPWD/stdcarsin ";")
			ecl_positions_array=$(echo ";$cad"|$PrPWD/stdcdr ";double RA"|$PrPWD/stdcarsin ";")
		        ecl_declinations_array=$(echo ";$cad"|$PrPWD/stdcdr ";double DECL"|$PrPWD/stdcarsin ";")
		        ecl_declinations_array=$(echo ";$cad"|$PrPWD/stdcdr ";double DECL"|$PrPWD/stdcarsin ";")
			ascecl=$(echo ";$cad"|$PrPWD/stdcdr "casas_RA={"|$PrPWD/stdcarsin ",")
		    fi


		    aspececl=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$aspececl.c" ];do
			aspececl=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done
		    
		    cat $PrPWD/swe/src/swe_ecl_a.c | $PrPWD/stdcar "double positions" > "$dirfn/$aspececl.c"
		    echo "$ecl_positions_array;" >> "$dirfn/$aspececl.c"
		    cat $PrPWD/swe/src/swe_ecl_a.c | $PrPWD/stdcdr "double positions" | $PrPWD/stdcdr ";" >> "$dirfn/$aspececl.c"
		    cat "$dirfn/$aspececl.c" | $PrPWD/stdcar "char planets" > "$dirfn/$aspececl-1.c"
		    echo "$ecl_planetas_array;" >> "$dirfn/$aspececl-1.c"
		    cat "$dirfn/$aspececl.c" | $PrPWD/stdcdr "char planets" | $PrPWD/stdcdr ";" >> "$dirfn/$aspececl-1.c"
		    cat "$dirfn/$aspececl-1.c" | $PrPWD/stdcar "char aspects" > "$dirfn/$aspececl.c"
		    echo "[5]={0,  60, 90, 120, 180}; " >> "$dirfn/$aspececl.c"
		    cat "$dirfn/$aspececl-1.c" | $PrPWD/stdcdr "char aspects" | $PrPWD/stdcdr ";" >> "$dirfn/$aspececl.c"
		    cat "$dirfn/$aspececl.c" | $PrPWD/stdcar "double toleranc" > "$dirfn/$aspececl-1.c"
		    echo "[5]={7, 3, 7, 7, 7};" >> "$dirfn/$aspececl-1.c"
		    cat "$dirfn/$aspececl.c" | $PrPWD/stdcdr "double toleranc" | $PrPWD/stdcdr ";" >> "$dirfn/$aspececl-1.c"
		    mv "$dirfn/$aspececl-1.c" "$dirfn/$aspececl.c"
		    aspectoseclipticoserrores=$(gcc -o "$dirfn/$aspececl" "$dirfn/$aspececl.c" -lm 2>&1 )
		    if [ -z "$aspectoseclipticoserrores" ];then
			cad=$("$dirfn/$aspececl")
			echo "<*<*<*<*<*"
			echo "$cad"
			echo "*>*>*>*>*>*>"
			variables=$(echo ";$cad"|$PrPWD/stddeclaracionesdevariable|tr '
' ';')
			variables=$(echo ";$variables"|$PrPWD/stddelcar ";static "|$PrPWD/stddelcar ";const ")
			echo "<<(($variables))>>"
			aspectosecl="";
			planet1=$(echo -n ";$variables" |$PrPWD/stdcdr ";char "|$PrPWD/stdcarsin ";")
			aspectosecl="$aspectosecl;char ecliptico_$planet1;"
			planet1=$(echo -n ";$variables" |$PrPWD/stddelcar " "|$PrPWD/stddelcar "intmain"|$PrPWD/stdcdr ";int"|$PrPWD/stdcarsin ";")
			aspectosecl="$aspectosecl;int ecliptico_$planet1;"
			aspectosnombre=$(echo -n "$planet1"|$PrPWD/stdcarsin "["|$PrPWD/stdcarsin "=")			
			planet1=$(echo -n ";$variables" |$PrPWD/stddelcar " "|$PrPWD/stdcdr ";double"|$PrPWD/stdcarsin ";")
			aspectosecl="$aspectosecl;double ecliptico_$planet1;"
			gradosn=$(echo -n "$planet1"|$PrPWD/stdcarsin "["|$PrPWD/stdcarsin "=")
			echo "<. <. < $gradosn|$aspectosnombre > .> .>"|$PrPWD/stddelcar " "
			variables=$(echo "$cad"|tr '
' ';'|$PrPWD/stddelcar " "|$PrPWD/stddelcar "$gradosn"|$PrPWD/stddelcar "$aspectosnombre")
			echo "<. <. < $variables > .> .>"|$PrPWD/stddelcar " "
			aspecto="ALGO"
			while [ -n "$aspecto" -a -n "$aspectosnombre" ];do
			    aspecto=$(echo -n "$variables"|$PrPWD/stdcdrcon ";$aspectosnombre"|$PrPWD/stdcarsin ";")
			    caracter=$(echo -n "$aspecto"|$PrPWD/stdcdr ";$aspectosnombre"|$PrPWD/stdcarn 1)
			    if [ "$caracter" = "[" -o "$caracter" = "=" ];then
				aspectosecl="$aspectosecl;$aspecto;"
			    fi
			    variables=$(echo "$variables"|$PrPWD/stdcdr ";$aspectosnombre")
			done
			variables=$(echo "$cad"|tr '
' ';'|$PrPWD/stddelcar " ")
			aspecto="ALGO"
			while [ -n "$aspecto" -a -n "$gradosn" ];do
			    aspecto=$(echo -n "$variables"|$PrPWD/stdcdrcon ";$gradosn"|$PrPWD/stdcarsin ";")
			    caracter=$(echo -n "$aspecto"|$PrPWD/stdcdr ";$gradosn"|$PrPWD/stdcarn 1)
			    if [ "$caracter" = "[" -o "$caracter" = "=" ];then
				aspectosecl="$aspectosecl;$aspecto;"
			    fi
			    variables=$(echo "$variables"|$PrPWD/stdcdr ";$gradosn")
			done
		    fi
		    
		    userd=$(echo -n "$fn"|$PrPWD/stdcdr "users/input/"|$PrPWD/stdcarsin "/")
		    echo "uuuuUUUUU   $userd UUUUuuuu "
		    mkdir $PrPWD/users/tooutput
		    mkdir $PrPWD/users/tooutput/$userd
		    ffd=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    while [ -f "$dirfn/$ffd.c" ];do
			ffd=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
		    done

		    mkdir peticiones
		    mv "$dirfn/$ffc.c" peticiones/
		    if [ -n "$timeerrores" -o -n "$aspectroseclerrores" -o -n "$ascendenteerrores" -o -n "$utctojulianerror" -o -n "$posicioneclipticoserrores" -o -n "$aspectoseclipticoserrores" ];then
			echo "FORMATO DE FECHA: $timeerrores ERROR EN CALCULO DE POSICION ASCENCIONAL: $aspectroseclerrores ERROR EN CALCULO DE ASCENDENTE: $ascendenteerrores ERROR EN CONVERSION DE UTC A JD: $utctojulianerror ERROR EN CALCULO DE POSICION ECLIPTICA: $posicioneclipticoserrores ERROR EN CALCULO DE ASPECTOS: $aspectoseclipticoserrores" > "$dirfn/$ffd.html"
			echo "FORMATO DE FECHA: $timeerrores ERROR EN CALCULO DE POSICION ASCENCIONAL: $aspectroseclerrores ERROR EN CALCULO DE ASCENDENTE: $ascendenteerrores ERROR EN CONVERSION DE UTC A JD: $utctojulianerror ERROR EN CALCULO DE POSICION ECLIPTICA: $posicioneclipticoserrores ERROR EN CALCULO DE ASPECTOS: $aspectoseclipticoserrores"
		    else
			ett=$(echo "$et" | "$dirfn/$ffc")
			echo "<<< $ett >>>"
			ASC=$(echo "$ett" | $PrPWD/stdcdr ";ASC(ramc)=" | $PrPWD/stdcarsin ";"|$PrPWD/stddelcar " ")
			DASC=$(echo "$ett" | $PrPWD/stdcdr ";DECLASC=" | $PrPWD/stdcarsin ";")
			e=$(echo "$ett" | $PrPWD/stdcdr "e=" | $PrPWD/stdcarsin ";")
			MC=$(echo "$ett" | $PrPWD/stdcdr ";MC=" | $PrPWD/stdcarsin ";")
			ARMC=$(echo "$ett" | $PrPWD/stdcdr ";RAMC(p)=" | $PrPWD/stdcarsin ";")

			outputc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
			while [ -f "$PrPWD/users/tooutput/$userd/$outputc.c" ];do
			    outputc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
			done
			echo "#include <stdio.h>\n#include <time.h>\nint main(int argc, unsigned char *argv[]) {time_t fecha=$fecha;double latitud=$latitud; double longitud=$longitud; double ascendente=$ascecl;double ascendente_ascencional=$ASC;double armc=$ARMC;double mid_coeli=$MC;double et=$et;double tjd=$tjd;double planetas_ascencional$positions_array; $aspectosasc;double planetas_ecliptico$ecl_positions_array;$aspectosecl;}" > $PrPWD/users/tooutput/$userd/$outputc.c
			cat $PrPWD/users/tooutput/$userd/$outputc.c
			mkdir peticiones
			#    			mv $dirfn/$ffd* peticiones/
		    fi			    
		fi
		mkdir peticiones
    		# mv $dirfn/$swecl*.c peticiones/
    		# mv $dirfn/$tjdf*.c peticiones/
		# mv $dirfn/$aspecas*.c peticiones/
		# mv $dirfn/$aspececl*.c peticiones/
    		# mv $dirfn/$ffc* peticiones/
		#    		mv $fn peticiones/
		#    		mv $fn.* peticiones/
	    fi
	fi
    fi
fi
