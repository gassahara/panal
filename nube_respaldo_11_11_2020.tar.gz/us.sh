dos=$(read -n UNO | ./stdtohex)
echo "$dos" | ./stdfromhex

