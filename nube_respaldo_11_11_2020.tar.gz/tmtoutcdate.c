#include <time.h>
#include <stdio.h>
#include <stdlib.h>   // for putenv
 
int main(void)
{
    time_t t=-203209439068/1000;
    struct tm *buf;
    buf=gmtime(&t);
    printf("%04d/%02d/%02d %02d:%02d UTC", 1900+buf->tm_year, buf->tm_mon, buf->tm_mday, buf->tm_hour, buf->tm_min);
}
