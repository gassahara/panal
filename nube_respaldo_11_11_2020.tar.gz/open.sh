emacs -nw querysubeusuario0.sh querybuscacsusuario1.sh querybuscacsusuario3.sh querydescargausuario0.sh opx5.html
