echo "$1*1000" | bc -l
