#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) (			\
	a += b,  d ^= a,  d = ROTL(d,16),	\
	c += d,  b ^= c,  b = ROTL(b,12),	\
	a += b,  d ^= a,  d = ROTL(d, 8),	\
	c += d,  b ^= c,  b = ROTL(b, 7))
#define ROUNDS 20
//nbytes numero de caracteres q representan un numero
uint32_t* num_from_string(char* str, int nbytes, int ll) {
  int i = strlen(str);// - (2 * WORD_SIZE); /* index into string */
  int j = 0;                        /* index into array */
  int k=0;
  int kk=0;
  int tmpd;
  char tmpc;
  int pasa=0;
  uint32_t *tmparray;
  tmparray=calloc(ll, sizeof(uint32_t));

  k=0;
  long tmp=0;
  while (i >= 0) {
    if(k==nbytes) {
      k=0;
      j++;
      tmp=0;
    }
    tmpc=str[i];
    pasa=0;
    kk=0;
    if(tmpc>=48 && tmpc<=57) {
      tmpd=(int)tmpc-48;
      pasa=1;
      kk=1;
    }
    if(pasa) {
      tmp=tmp+(tmpd*(pow(10,k)));
      k++;
    } else {
      if(kk) break;
    }
    tmparray[i/2]=tmp;
    i--;    
  }
    fflush(stdout);
  return tmparray;
}
 
int main( int argc, char *argv[] ) {
  uint32_t out[16], *in;
  int i;
  uint32_t x[16];

  char buffer[2048];
  char buff[1];
  int r=1;
  int rr=0;
  int t=0;
  
  bzero(buffer, sizeof(buffer));
  while(r>0 && rr < 16) {
    r=fread(buff, sizeof(char), 1, stdin);
    if(r<1) break;
    buffer[rr]=buff[0];
    rr++;
  }
  if (rr < 16) {
    printf("la entrada debe contener al menos 16 bytes");
    exit(1);
  }
  in = num_from_string(buffer, 2, 16);
  for (i = 0; i < 16; ++i)	
    x[i] = in[i];
  // 10 loops × 2 rounds/loop = 20 rounds
  for (i = 0; i < ROUNDS; i += 2) {
    // Odd round
    QR(x[0], x[4], x[ 8], x[12]); // column 0
    QR(x[1], x[5], x[ 9], x[13]); // column 1
    QR(x[2], x[6], x[10], x[14]); // column 2
    QR(x[3], x[7], x[11], x[15]); // column 3
    // Even round
    QR(x[0], x[5], x[10], x[15]); // diagonal 1 (main diagonal)
    QR(x[1], x[6], x[11], x[12]); // diagonal 2
    QR(x[2], x[7], x[ 8], x[13]); // diagonal 3
    QR(x[3], x[4], x[ 9], x[14]); // diagonal 4
  }
  for (i = 0; i < 16; ++i) {
    out[i] = x[i] + in[i];
    printf("%08X", out[i]);
  }
}
