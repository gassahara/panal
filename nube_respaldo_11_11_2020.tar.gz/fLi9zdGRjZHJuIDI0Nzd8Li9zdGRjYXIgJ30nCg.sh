cat datas/C1 |  | ./stcdr '{' | ./stdcarsin '}' 
