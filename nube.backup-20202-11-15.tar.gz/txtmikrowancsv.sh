echo "$1"
cat "$1" | ./detxtamikrowan > "$1.csv"

