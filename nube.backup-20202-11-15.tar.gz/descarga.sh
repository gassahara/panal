curl  --insecure  "ftp://ftpupload.net/htdocs/panal/86237937" --user "b31_25960168:Effata1581"
curl  --insecure  -s "ftp://ftpupload.net/htdocs/panal/" -X MLSD --user "b31_25960168:Effata1581"
curl  --insecure  -X "DELE RIND.html" "ftp://ftpupload.net/htdocs/panal/" --user "b31_25960168:Effata1581"

curl  --insecure  "ftp://files.000webhost.com/public_html/panal/"  -X MLSD --user "curare2019:Effata1581"
