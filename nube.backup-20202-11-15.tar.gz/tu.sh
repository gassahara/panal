#!/usr/bin/bash
IFS=""
./stdcdr "boundary="
./stdcarsin $'\n' 
echo "===="
