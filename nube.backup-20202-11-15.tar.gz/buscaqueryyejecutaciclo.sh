while [ 1 ];do
    ./buscaqueryyejecuta.sh
    sleep 1
done