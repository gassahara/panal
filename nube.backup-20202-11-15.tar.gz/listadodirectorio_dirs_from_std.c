#include <stdio.h>
#include <stdlib.h>
#include <sys/dir.h>

/*
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/dir.h>
#include <unistd.h>
*/

int main(int argc, char *argv[]) {
  //  char *path,*name;
  DIR *pdyr;

  struct dirent *pent = NULL;
  char *buffer;
  int ssize=256;
  buffer=calloc(ssize, sizeof(char));
  char *temporal;
  int m=0;
  while(m<ssize) {
    buffer[m]= 0;
    m++;
  }
  char buff[2];
  int r=1;
  int rr=0;
  int rt=ssize;
  int offset=0;
  
  while(r>0) {
    r=fread(buff, sizeof(char), 1, stdin);
    if(buff[0] == '\n' || buff[0] == 0) break;
    if(r<1) break;
    buffer[rr]=buff[0];
    rr++;
    while(rr>rt-1) {
      temporal=calloc(rr, sizeof(char));
      m=0;
      while(m<rr) {
	temporal[m]=buffer[m];
      }
      free(buffer);
      buffer=calloc(rr+ssize, sizeof(char));
      r=0;
      while(r<rr+ssize) {
	buffer[r]=0;
	r++;
      }
      m=0;
      while(m<rr+ssize) {
	buffer[m]=0;
	m++;
      }
      m=0;
      while(m<rr) {
	buffer[m]=temporal[m];
      }
      free(temporal);
      rt=rr+ssize;
    }
  }
  buffer[rr]=0;
  pdyr=opendir (buffer);
  if (pdyr != NULL) {
    while ( (pent = readdir (pdyr)) !=NULL) {
      if ( !(pent->d_name[0]=='.' && pent->d_name[1]=='.' && pent->d_name[2]==0) && !(pent->d_name[0]=='.' && pent->d_name[1]==0) ){
	if (pent->d_type==DT_DIR){ 
	  printf("%s/%s\n", buffer, pent->d_name);
	}
      }
    }
  }
}
