<!doctype html>
<!--
-->
<html>
<head>
    <title>Registrar Identidad</title>
</head>
<body>
  <FORM METHOD="POST" ENCTYPE="multipart/form-data">
    <p>Usuario: <input name="usuario" /></p>
    <p>Clave: </p><TEXTAREA name="clave" /></TEXTAREA><br><br>
    <input type="submit" value="REGISTRAR">
  </FORM>
</body>
</html>

