#!/bin/sh
fn=""
PaPWD="$PWD"
stdcdr="stdcdr"
stdcdrd=""
while [ ! -f "$stdcdrd$stdcdr" ];do
    stdcdrd=$(echo "../$stdcdrd")
done
PrPWD=$stdcdrd
pasa=0
nomprograma=$0
slash=$(echo "$nomprograma"| $PrPWD/stdbuscaarg_donde_hasta "/" )
while [ -n "$slash" ];do
    nomprograma=$(echo "$nomprograma"| $PrPWD/stdcdr "/" )
    slash=$(echo "$nomprograma" | $PrPWD/stdbuscaarg_donde_hasta "/" )
done
cd $PrPWD
PrPWD2=$PWD
PrPWD=$PrPWD2
cd $PaPWD
#echo "$nomprograma.."
usuarioftp="b14_26624723"
passwordftp="Effata1581"
remotepath="ftpupload.net/htdocs"
sleep 2
curl  --insecure  "ftp://$remotepath/panal/msgs/"  -X MLSD --user "$usuarioftp:$passwordftp"  2>/dev/null | $PrPWD/stdcdr '..
' > $nomprograma.lis
PbPWD=$(echo "$PaPWD"|$PrPWD/stdcdr "$PrPWD")
busca=".."
echo -n "" > $nomprograma.cha
posicion=0;
dondes=$( cat "$nomprograma.lis" |$PrPWD/stdbuscaarg_donde '
')
encuentra="ALGO"
while [ -n "$dondes" -a -n "$encuentra" ];do
    posicion2=$(echo "$dondes"|$PrPWD/stdcarsin " ")
    posicion2=$(expr 0$posicion2 - 0$posicion + 1)
    listf=$(cat "$nomprograma.lis" | $PrPWD/stdcdrn "0$posicion"|$PrPWD/stdcarn $posicion2)
    sizelistf=$(echo -n "$listf" | $PrPWD//stdcdr "size="|$PrPWD/stdcar ";")
    listf=$(cat "$nomprograma.lis" | $PrPWD/stdcdrn "0$posicion"|$PrPWD/stdcarn $posicion2|$PrPWD/stdcdr " ")
    listf=$(echo -n "$sizelistf$listf")
    posicion=$(expr 0$posicion2 + $posicion)
    dondes=$(echo -n "$dondes" |$PrPWD/stdcdr " ")
    chacha=$(echo -n " $listf"|$PrPWD/stdtohex |$PrPWD/chacha20)
    encuentra=$(cat $nomprograma.memoria | $PrPWD/stdbuscaarg ";$listf;$chacha;")
done
if [ -n "$dondes" ];then
    $0 &
else
    ps1=3
    while [ 0$ps1 -gt 2 ];do
    	ps1=$(ps -Am -o ";%c:" |  $PrPWD/stddelcar " " | $PrPWD/stdbuscaarg_count ";$nomprograma:" )
    	sleep 2
    done
    $0 &
fi
if [ -z "$encuentra" -a -n "$listf" ];then
    fn=$(echo -n "$listf"|$PrPWD/stdcdr ";" )
    tamano=$(echo -n "$listf"|$PrPWD/stdcarsin ";" )
    echo "<< fn $fn ($listf) >>"
    ttest=$(echo -n "$fn" |$PrPWD/stddelcar " ")
    if [ -n "$ttest" ];then
	slash=$(echo "$fn" | $PrPWD/stdbuscaarg_donde_hasta "/" )
	while [ -n "$slash" ];do
	    fn=$(echo "$fn" | $PrPWD/stdcdr "/" )
	    slash=$(echo $fn | $PrPWD/stdbuscaarg_donde_hasta "/" )
	done
	#    	echo "0 $busca ($fn)"
	len=$(echo -n "$fn"|wc -c)
	if [ 0$len -gt 0 -a ! -f "$fn" ];then
	    len=1
	    while [ $len -lt $tamano ];do
		curl  --insecure  "ftp://$remotepath/panal/msgs/$fn" --user "$usuarioftp:$passwordftp" 2>/dev/null 1>$fn
		len=$(dd if=$fn bs=1|wc -c)
	    done
	fi
	if [ 0$len -gt 0 -a  -f "$fn" ];then
	    opens=$(cat "$fn"|$PrPWD/stdbuscaarg_count "BEGIN PGP MESSAGE")
	    closs=$(cat "$fn"|$PrPWD/stdbuscaarg_count "END PGP MESSAGE")
	    balan=$(( $opens-$closs ))
	    if [ 0$opens -gt 0 -a "$balan" = "0"  ];then
		echo ";$listf;$chacha;" >> $nomprograma.memoria
		cat $fn | gpg -a --no-default-keyring --keyring $PrPWD/user/key.key  -d 2>/dev/null 1>$fn.c
		mains=$(cat "$fn.c"|$PrPWD/stdbuscaarg " main")
		opens=$(cat "$fn.c"|$PrPWD/stdcdr " main"|$PrPWD/stdbuscaarg_count "{")
		closs=$(cat "$fn.c"|$PrPWD/stdcdr " main"|$PrPWD/stdbuscaarg_count "}")
		balan=$(echo "$opens-$closs"|bc)
		if [ 0$opens -gt 0 -a "$balan" = "0" -a -n "$mains" ];then
    		    ejec="$fn.$nomprograma.bin"
    		    errors=$(gcc -o ./$ejec $fn.c 2>&1)
		    echo "$ejec"
		    mkdir peticiones
		    if [ -z "$errors" ];then
			variables=$(cat $fn.c |$PrPWD/stddeclaracionesdevariable|$PrPWD/stdtohex|$PrPWD/stddelcar 0A|$PrPWD/stdfromhex)
			userfromfile=$(echo ";$variables" |$PrPWD/stdcdr ";char *"|$PrPWD/stdcarsin "=")
			ttest=$(echo ";$variables" |$PrPWD/stdbuscaarg_donde_hasta ";int ")
			echo "<<< ttest $ttest >>>"
			dondes=0
			while [ "0$ttest" -gt 0 ];do
			    dondes=$(($dondes+$ttest))
			    ivfromfile=$(echo ";$variables" |$PrPWD/stdcdrn $dondes|$PrPWD/stdcarsin ";")
			    echo "-> $ivfromfile"
			    len=$(echo $ivfromfile|$PrPWD/stdcdr "]"|$PrPWD/stdbuscaarg_donde_hasta "[16]")
			    len2=$(echo $ivfromfile|$PrPWD/stdbuscaarg_count "][")
			    if [ 0$len -gt 0 -a 0$len2 -eq 1 ];then
				ivfromfile=$(echo "$ivfromfile"|$PrPWD/stdcarsin "[16]"|$PrPWD/stdcarsin "[")
				break;
			    else
				ivfromfile=""
			    fi
			    ttest=$(echo ";$variables" |$PrPWD/stdcdrn $dondes|$PrPWD/stdbuscaarg_donde_hasta ";int ")
			    echo "<<< ttest $ttest d $dondes>>>"
			done

			ttest=$(echo ";$variables"| $PrPWD/stddelcar "int $ivfromfile"|$PrPWD/stdbuscaarg_donde_hasta ";int ")
			echo "________________________________________________________"
			echo ";$variables"| $PrPWD/stddelcar "int $ivfromfile"
			echo "......................................................."
			echo "<<< ttest $ttest >>>"
			dondes=0
			while [ "0$ttest" -gt 0 ];do
			    dondes=$(($dondes+$ttest))
			    encryptedfromfile=$(echo ";$variables"| $PrPWD/stddelcar "int $ivfromfile"|$PrPWD/stdcdrn $dondes|$PrPWD/stdcarsin ";")
			    echo "()> $encryptedfromfile"
			    len=$(echo $encryptedfromfile|$PrPWD/stdcdr "]"|$PrPWD/stdbuscaarg_donde_hasta "[")
			    len2=$(echo $encryptedfromfile|$PrPWD/stdbuscaarg_count "][")
			    if [ 0$len -gt 0 -a 0$len2 -eq 1 ];then
				encryptedfromfile=$(echo "$encryptedfromfile"|$PrPWD/stdcarsin ";"|$PrPWD/stdcarsin "[")
				break;
			    else
				encryptedfromfile=""
			    fi
			    dondes=$(($dondes+$ttest))
			    ttest=$(echo ";$variables"| $PrPWD/stddelcar "int $ivfromfile"|$PrPWD/stdcdrn $dondes|$PrPWD/stdbuscaarg_donde_hasta ";int ")
			    dondes=$(($dondes+0$ttest))
			    echo "<<< ttest $ttest d $dondes>>>"
			done

			filedfromfile=$(echo ";$variables" |$PrPWD/stdcdr ";FILE *"|$PrPWD/stdcarsin "="|$PrPWD/stdcarsin ";")
			ca5=$(echo "$userfromfile $ivfromfile $encryptedfromfile $filedfromfile"|$PrPWD/stdbuscaarg " 0")
			echo "<$userfromfile> <$ivfromfile> <$encryptedfromfile> <$filedfromfile> <$ca5>"
			if [ -n "$userfromfile" -a -n "$ivfromfile" -a -n "$encryptedfromfile" -a -n "$filedfromfile" -a -z "$ca5" ];then
			    cat $fn.c |$PrPWD/stdcdr "*$userfromfile=" # |$PrPWD/stddelcar '"'
			    usuarioo=$(echo ";$variables" |$PrPWD/stdcdr "$userfromfile=" |$PrPWD/stddelcar '"' | $PrPWD/stdcarsin ";");
			    echo "uU $usuarioo Uu $userfromfile uU"
			    if [ -f "$PrPWD/user/$usuarioo-aes.c" ];then
				outputdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				while [ -f "$outputdelc.c" ];do
				    outputdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				done
				echo "oOO $outputdelc OOo"
				arrayindex=$(cat $fn.c | $PrPWD/stdcdr "int $ivfromfile["  | $PrPWD/stdcarsin "]");
				dondes=0
				iv=$(echo "$variables" | $PrPWD/stdcdr "int $ivfromfile["  | $PrPWD/stdcarsin ";");
				msj=$(echo "$variables" | $PrPWD/stdcdr "int $encryptedfromfile["|$PrPWD/stdcarsin ";");
				filed=$(cat $fn.c | $PrPWD/stdcdr "$filedfromfile=" | $PrPWD/stdcdr "fopen(" |$PrPWD/stddelcar '"' | $PrPWD/stdcarsin ",");
				c=0
				tail $PrPWD/user/$usuarioo-aes.c
				echo "IV $ivfromfile $iv"
				cat $PrPWD/user/$usuarioo-aes.c | $PrPWD/stdcar "unsigned char iv[" > $outputdelc.c
				echo "$iv;" >> $outputdelc.c
				cat $PrPWD/user/$usuarioo-aes.c | $PrPWD/stdcdr "unsigned char iv[" | $PrPWD/stdcdr ";" >> $outputdelc.c

				cat $outputdelc.c | $PrPWD/stdcar "unsigned char buf[" > $outputdelc-2.c
				echo "$msj;" >> $outputdelc-2.c
				cat $outputdelc.c | $PrPWD/stdcdr "unsigned char buf[" | $PrPWD/stdcdr ";" >> $outputdelc-2.c
				mv $outputdelc-2.c $outputdelc.c

				echo "$outputdelc.c"
				tail $outputdelc.c
				errores=$(gcc -o $outputdelc-bin $outputdelc.c 2>&1)
				echo "< < < $errores > > >"
				if [ -z "$errores" ];then
				    datosdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				    while [ -f "$datosdelc.c" ];do
					datosdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				    done
				    $PaPWD/$outputdelc-bin
				    echo "$datosdelc.c"
				    $PaPWD/$outputdelc-bin > $datosdelc.c
				    cat "$datosdelc.c"
				    echo "==================="

				    outputdelcu=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				    while [ -f "$outputdelcu.c" ];do
					outputdelcu=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				    done
				    cat $datosdelc.c|$PrPWD/stdcdr "int buf["|$PrPWD/stdcarsin ";"|$PrPWD/stdcdr "=" |$PrPWD/stdfromdec > $outputdelcu.c
				    errores=$(gcc -o $outputdelcu-bin $outputdelcu.c 2>&1)
				    echo "<( $errores ])>"
				    if [ -z "$errores" ];then
					mkdir $PrPWD/users
					mkdir $PrPWD/users/input
					mkdir $PrPWD/users/input/$usuarioo
					cp -v $outputdelcu.c $PrPWD/users/input/$usuarioo/
				    fi
				fi
			    else
				datosdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				while [ -f "$datosdelc.c" ];do
				    datosdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				done
				outputdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				while [ -f "$outputdelc.c" ];do
				    outputdelc=$(dd if=/dev/random bs=1 count=10 2>/dev/null |$PrPWD/stdtohex|$PrPWD/stddelcar " ")
				done
				echo "errores=\"Error de usuario de nombre de usuario o contraseña\";" > $outputdelc
				echo "processed=255;" >> $outputdelc
			    fi
			    if [ -n "$errores" ];then
				echo "errores=\"Error de usuario de nombre de usuario o contraseña\";" > $outputdelc
				echo "processed=255;" >> $outputdelc
			    else
				echo "errores=\"Entrada registrada correctamente, en cuanto se encunetre procesada aparecera la respuesta en la lista de mensajes (con el titulo indicado en la entrada)\";" > $outputdelc
				echo "processed=255;" >> $outputdelc
			    fi
			    echo -n "encrypted="'`' > $datosdelc.js
			    cat $outputdelc | gpg -a --no-default-keyring --keyring $PrPWD/user/key.key  --sign  >> $datosdelc.js
			    echo '`'";"  >> $datosdelc.js
			    echo "processed=255;"  >> $datosdelc.js
			    curl --insecure  --user "$usuarioftp:$passwordftp" -T $datosdelc.js "ftp://$remotepath/panal/msgs/$filed"
			    mv $outputdelc* peticiones/
			    mv $datosdelc* peticiones/
			    mv $outputdelc* peticiones/
			    mv $usarioo_$outputdelcu.c peticiones/
			    mv $outputdelcu* peticiones/
			    mv $datosdelc* peticiones/
			else
			    echo "======================="
			    echo "$errores"
			fi
			mv $fn peticiones/
    			mv $fn.* peticiones/
		    fi
		else
		    rm $fn
		fi
	    fi
	fi
    fi
fi
